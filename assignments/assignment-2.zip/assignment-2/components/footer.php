<?php echo '      
      <footer class="mb-3">
        <a href="#navbar" class="link-secondary"">Back to top</a>
      </footer>'
?>